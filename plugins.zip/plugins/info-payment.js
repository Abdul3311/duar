let handler = async (m, { conn }) => {
let pay = 'https://telegra.ph/file/6905668d28c08644465c2.jpg'
let payy = `Payment/Pembayaran 

[-] Gopay : 082112309624
[-] Dana : 0895347198105
[-] ShopeePay : 082112309624
[-] Saweria : https://saweria.co/Arifzyn
[-] Website : https://lynk.id/arif_zyn

Akun Belum Premium ? 
Bisa Scan Qris Di Atas 

Note : Jika Sudah Bayar Silahkan kirim Bukti Ke Owner !!`
conn.sendButtonImg(m.chat, pay, payy, author, 'Owner', '.owner', m)
}
handler.help = ['payment', 'pay']
handler.tags = ['info', 'store']
handler.command = /^(pay|payment)$/i

export default handler
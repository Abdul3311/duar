import fetch from 'node-fetch'
import { sendArifMessage } from '../lib/message.js'

let handler  = async (m, { conn, usedPrefix }) => {
let pp = 'https://telegra.ph/file/abae15ef77d530d1bcd49.jpg'
let thum = await conn.resize(pp, 300, 300)
let name = await conn.getName(m.sender)
let donasi = `Hai ${name}, Ingin Donasi ?

Gopay: 085838225041
Pulsa TEL: 085268581456
Dana: 085838225041

Note : Jika Sudah Donasi Silahkan
Kirim Bukti Ke Ke Owner !

My Owner : https://w.me/6285838225041`
sendArifMessage(m.chat,  { 
text: donasi,
mentions:[m.sender],
contextInfo:{
mentionedJid:[m.sender],
"externalAdReply": {
"showAdAttribution": true,
"renderLargerThumbnail": true,
"title": 'Support Me', 
"containsAutoReply": true,
"mediaType": 1, 
"thumbnail": thum,
"sourceUrl": 'https://saweria.co/Arifzyn'
}
}
})
}
handler.tags = ['donasi', 'donate']
handler.help = ['info']
handler.command = /^(donate|donasi)$/i

export default handler